const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');

module.exports = {
  mode: 'development', // Установка режима сборки
  entry: './src/index.js', // Главный файл для сборки
  output: {
    filename: 'bundle.js', // Выходной файл
    path: path.resolve(__dirname, 'dist') // Папка для выходных файлов
  },
  module: {
    rules: [
      {
        test: /\.scss$/, // Загрузчик для SCSS файлов
        use: [
          'style-loader', // Вставляет стили в DOM
          'css-loader', // Интерпретирует @import и url() как import/require()
          'sass-loader' // Компилирует SCSS в CSS
        ]
      },
      {
        test: /\.html$/, // Загрузчик для HTML файлов
        use: [
          'html-loader' // Экспортирует HTML как строку
        ]
      }
    ]
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: './src/index.html', // Шаблон HTML файла
      filename: 'index.html'
    }),
    new CopyWebpackPlugin({
      patterns: [
        { from: 'src/**/*.php', to: '[name].[ext]' },
        { from: 'public', to: 'public' } // копирует папку public
      ]
    })
  ],
  devServer: {
    static: {
      directory: path.join(__dirname, 'dist'), // Папка для сервера разработки
    },
    compress: true,
    port: 9001 // Использование другого порта
  }
};
